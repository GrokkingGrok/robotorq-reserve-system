use crate::types::JouleTorqOre;
use pqcrypto_dilithium::dilithium2::{self, PublicKey, SecretKey};
use std::time::{SystemTime, UNIX_EPOCH};

pub struct Digger {
    pub id: String,
    pub rtp: u16,
    pub torq_factor: u16,
    pub secret_key: SecretKey, // In real life, load from disk/wallet
}

impl Digger {
    pub fn new(id: String, rtp: u16, torq_factor: u16) -> Self {
        // In production: load from secure storage
        let sk = dilithium2::secret_key_from_seed(&[0u8; 32]);
        Self { id, rtp, torq_factor, secret_key: sk }
    }

    pub fn generate_ore(&self) -> JouleTorqOre {
        let tokens_per_sec = (self.rtp as u64) * (self.torq_factor.saturating_sub(1) as u64);
        let joule_per_sec = (self.rtp as u64) * 3600;

        JouleTorqOre {
            digger_id: self.id.clone(),
            rtp: self.rtp,
            torq_factor: self.torq_factor,
            joule: joule_per_sec,
            robo_stake: self.rtp as u64,
            price: self.torq_factor as f64,
            bonded_tokens: self.sign_tokens(tokens_per_sec),
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        }
    }

    fn sign_tokens(&self, count: u64) -> Vec<String> {
        (0..count)
            .map(|i| {
                let msg = format!("{}-{}", self.id, i);
                let sig = dilithium2::sign(msg.as_bytes(), &self.secret_key);
                base64::encode(sig)
            })
            .collect()
    }
}