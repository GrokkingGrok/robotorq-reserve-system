#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

mod digger;
mod types;

use digger::Digger;
use tauri::Manager;
use types::JouleTorqOre;

#[tauri::command]
async fn start_digging(digger_cfg: DiggerConfig) -> Result<JouleTorqOre, String> {
    let digger = Digger::new(
        digger_cfg.id,
        digger_cfg.rtp,
        digger_cfg.torq_factor,
    );
    Ok(digger.generate_ore())
}

#[derive(serde::Deserialize)]
struct DiggerConfig {
    id: String,
    rtp: u16,
    torq_factor: u16,
}

fn main() {
    env_logger::init();

    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![start_digging])
        .run(tauri::generate_context!())
        .expect("error while running Tauri application");
}