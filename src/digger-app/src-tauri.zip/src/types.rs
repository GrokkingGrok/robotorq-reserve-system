use serde::Serialize;

#[derive(Serialize)]
pub struct JouleTorqOre {
    pub digger_id: String,
    pub rtp: u16,
    pub torq_factor: u16,
    pub joule: u64,
    pub robo_stake: u64,
    pub price: f64,
    pub bonded_tokens: Vec<String>,
    pub timestamp: u64,
}